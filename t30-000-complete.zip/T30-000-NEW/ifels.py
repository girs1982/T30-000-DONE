from time import sleep
a = 1

while 1:
  if a==1:
     print("huuy")
     a=0
  else:
     print("pizda")
     sleep(1)
     a=1

